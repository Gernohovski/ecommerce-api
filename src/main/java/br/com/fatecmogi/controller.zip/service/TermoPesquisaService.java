package br.com.fatecmogi.service;

import java.util.List;

public interface TermoPesquisaService {

	public String calcularTermoPesquisa(List<String> parametros);

}
