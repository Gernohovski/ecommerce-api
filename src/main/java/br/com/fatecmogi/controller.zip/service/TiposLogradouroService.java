package br.com.fatecmogi.service;

import br.com.fatecmogi.model.entity.endereco.TipoLogradouro;

import java.util.List;

public interface TiposLogradouroService {

	List<TipoLogradouro> findAll();

}
