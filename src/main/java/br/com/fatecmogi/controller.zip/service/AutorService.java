package br.com.fatecmogi.service;

import br.com.fatecmogi.model.entity.livro.Autor;

import java.util.List;

public interface AutorService {

	List<Autor> listar();

}
