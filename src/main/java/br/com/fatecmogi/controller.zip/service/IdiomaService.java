package br.com.fatecmogi.service;

import br.com.fatecmogi.model.entity.livro.Idioma;

import java.util.List;

public interface IdiomaService {

	List<Idioma> listar();

}
