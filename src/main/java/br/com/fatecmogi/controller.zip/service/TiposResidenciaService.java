package br.com.fatecmogi.service;

import br.com.fatecmogi.model.entity.endereco.TipoResidencia;

import java.util.List;

public interface TiposResidenciaService {

	List<TipoResidencia> findAll();

}
