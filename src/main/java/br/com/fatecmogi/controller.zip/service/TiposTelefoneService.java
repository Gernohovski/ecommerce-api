package br.com.fatecmogi.service;

import br.com.fatecmogi.model.entity.cliente.TipoTelefone;

import java.util.List;

public interface TiposTelefoneService {

	List<TipoTelefone> findAll();

}
