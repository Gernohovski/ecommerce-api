package br.com.fatecmogi.service;

import br.com.fatecmogi.model.entity.cliente.Genero;

import java.util.List;

public interface GenerosService {

	List<Genero> findAll();

}
