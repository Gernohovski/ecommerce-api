package br.com.fatecmogi.service;

import br.com.fatecmogi.model.entity.cartaoCredito.BandeiraCartao;

import java.util.List;

public interface BandeirasCartaoService {

	List<BandeiraCartao> findAll();

}
