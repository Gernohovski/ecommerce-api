package br.com.fatecmogi.model.enums;

public enum TiposInteracao {

	RECOMENDACAO, QUIZ, CURIOSIDADE

}
