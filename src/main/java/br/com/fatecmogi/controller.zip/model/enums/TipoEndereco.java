package br.com.fatecmogi.model.enums;

public enum TipoEndereco {

	RESIDENCIAL, ENTREGA, COBRANCA

}
